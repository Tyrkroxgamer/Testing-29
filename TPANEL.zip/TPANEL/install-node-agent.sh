#!/usr/bin/env bash
set -Eeuo pipefail
if [[ $EUID -ne 0 ]]; then echo 'Run as root: sudo bash install-node-agent.sh'; exit 1; fi
command -v apt-get >/dev/null || { echo 'Ubuntu/Debian only'; exit 1; }
read -rp 'Panel VPS private/public IP allowed to connect: ' PANEL_IP
[[ "$PANEL_IP" =~ ^[0-9a-fA-F:.]+$ ]] || { echo 'Invalid IP'; exit 1; }
read -rsp 'Shared token (minimum 24 characters; same token entered in T PANEL Admin > Register Node): ' TOKEN; echo
(( ${#TOKEN} >= 24 )) || { echo 'Token must be at least 24 characters'; exit 1; }
apt-get update
apt-get install -y python3 docker.io
systemctl enable --now docker
install -d -m 750 /opt/t-panel-node
install -m 750 "$(dirname "$0")/node-agent.py" /opt/t-panel-node/node-agent.py
umask 077
cat > /etc/t-panel-node.env <<ENV
TPANEL_NODE_TOKEN=$TOKEN
TPANEL_NODE_NAME=$(hostname | tr -cd 'A-Za-z0-9_.-')
TPANEL_NODE_BIND=0.0.0.0
TPANEL_NODE_PORT=8790
ENV
chmod 600 /etc/t-panel-node.env
cat > /etc/systemd/system/t-panel-node-agent.service <<'UNIT'
[Unit]
Description=T PANEL Remote Node Agent
After=network.target docker.service
Requires=docker.service
[Service]
Type=simple
EnvironmentFile=/etc/t-panel-node.env
ExecStart=/usr/bin/python3 /opt/t-panel-node/node-agent.py
Restart=on-failure
RestartSec=3
NoNewPrivileges=true
PrivateTmp=true
ProtectHome=true
ProtectSystem=full
ReadWritePaths=/opt/t-panel-node
[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable --now t-panel-node-agent
if command -v ufw >/dev/null && ufw status | grep -q 'Status: active'; then ufw allow from "$PANEL_IP" to any port 8790 proto tcp; else echo 'WARNING: UFW is not active. Restrict TCP 8790 to the panel IP in your provider firewall before use.'; fi
unset TOKEN
echo 'Node agent installed.'
echo 'In T PANEL Admin > Register a Node, set endpoint to http://NODE_IP:8790 (prefer private VPN IP) and enter the same shared token.'
echo 'For public-network use, put this agent behind HTTPS and firewall it to the panel IP. Do not expose port 8790 to everyone.'
echo 'Logs: journalctl -u t-panel-node-agent -f'
