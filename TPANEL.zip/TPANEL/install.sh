#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_NAME="t-panel"
SERVICE_NAME="t-panel"
DEFAULT_PORT=8088

if [[ $EUID -ne 0 ]]; then
  echo "Run as root: sudo bash install.sh"
  exit 1
fi

if ! command -v apt-get >/dev/null 2>&1; then
  echo "This installer currently supports Ubuntu/Debian with apt-get."
  exit 1
fi

read -rp "Panel port [8088]: " PORT
PORT="${PORT:-$DEFAULT_PORT}"
if ! [[ "$PORT" =~ ^[0-9]+$ ]] || (( PORT < 1024 || PORT > 65535 )); then
  echo "Choose a port between 1024 and 65535 (not port 80)."
  exit 1
fi
if command -v ss >/dev/null 2>&1 && ss -ltn | awk '{print $4}' | grep -Eq "(:|\])${PORT}$"; then
  echo "Port $PORT is already in use. Choose another port and rerun."
  exit 1
fi

read -rp "Admin email: " ADMIN_EMAIL
if [[ ! "$ADMIN_EMAIL" =~ ^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$ ]]; then
  echo "Enter a valid email address."
  exit 1
fi
read -rsp "Admin password (at least 12 characters): " ADMIN_PASSWORD; echo
if (( ${#ADMIN_PASSWORD} < 12 )); then echo "Password must be at least 12 characters."; exit 1; fi
read -rsp "Confirm admin password: " ADMIN_PASSWORD_CONFIRM; echo
if [[ "$ADMIN_PASSWORD" != "$ADMIN_PASSWORD_CONFIRM" ]]; then echo "Passwords do not match."; exit 1; fi

echo "[1/5] Installing Java 21, Maven, and Docker..."
apt-get update
apt-get install -y openjdk-21-jdk maven curl docker.io
systemctl enable --now docker
java -version

echo "[2/5] Building T PANEL..."
cd "$APP_DIR"
if [[ ! -f pom.xml ]]; then echo "pom.xml not found in $APP_DIR"; exit 1; fi
mvn -q -DskipTests package

JAR_PATH="$(find "$APP_DIR/target" -maxdepth 1 -type f -name '*.jar' ! -name '*.original' | head -n 1)"
if [[ -z "$JAR_PATH" ]]; then echo "Build did not produce a JAR."; exit 1; fi

echo "[3/5] Installing application..."
install -d -m 750 /opt/t-panel
install -m 640 "$JAR_PATH" /opt/t-panel/t-panel.jar
install -d -m 750 /opt/t-panel/data /opt/t-panel/backups /opt/t-panel/servers
chown -R root:root /opt/t-panel

ENV_FILE="/etc/t-panel.env"
umask 077
cat > "$ENV_FILE" <<EOF
TPANEL_PORT=$PORT
TPANEL_ADMIN_EMAIL=$ADMIN_EMAIL
TPANEL_ADMIN_PASSWORD=$ADMIN_PASSWORD
EOF
unset ADMIN_PASSWORD ADMIN_PASSWORD_CONFIRM
chmod 600 "$ENV_FILE"

echo "[4/5] Configuring systemd..."
cat > /etc/systemd/system/t-panel.service <<'EOF'
[Unit]
Description=T PANEL Minecraft Hosting Panel
After=network.target

[Service]
Type=simple
WorkingDirectory=/opt/t-panel
EnvironmentFile=/etc/t-panel.env
ExecStart=/usr/bin/java -jar /opt/t-panel/t-panel.jar
Restart=on-failure
RestartSec=5
NoNewPrivileges=true
ProtectSystem=full
ReadWritePaths=/opt/t-panel/data /opt/t-panel/servers /opt/t-panel/backups
PrivateTmp=true

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable --now "$SERVICE_NAME"

echo "[5/5] Firewall..."
if command -v ufw >/dev/null 2>&1 && ufw status | grep -q "Status: active"; then
  read -rp "UFW is active. Allow TCP port $PORT? [y/N]: " ALLOW_PORT
  if [[ "$ALLOW_PORT" =~ ^[Yy]$ ]]; then ufw allow "$PORT/tcp"; fi
fi

sleep 2
if systemctl is-active --quiet "$SERVICE_NAME"; then
  # The password is needed only for first-run admin creation. Remove it from the
  # environment file after confirming that the app logged successful creation.
  sleep 2
  if journalctl -u "$SERVICE_NAME" --since "5 minutes ago" --no-pager 2>/dev/null | grep -Fq "initial administrator created for"; then
    sed -i '/^TPANEL_ADMIN_PASSWORD=/d' "$ENV_FILE"
    chmod 600 "$ENV_FILE"
    systemctl restart "$SERVICE_NAME"
  fi
  echo
  echo "T PANEL service is running."
  echo "URL: http://YOUR_SERVER_IP:$PORT"
  echo "Admin email: $ADMIN_EMAIL"
  echo "The initial password is not displayed. The installer removes it from the environment file after successful first-admin creation."
  echo "Logs: journalctl -u t-panel -f"
  echo "Restart: systemctl restart t-panel"
  echo "Check status: systemctl status t-panel"
  echo "IMPORTANT: Also allow TCP $PORT in your VPS provider's external firewall/security group."
  echo "NOTE: Local Docker Minecraft servers, file manager, ZIP backups, scheduled backups, RCON console, and T PANEL Node Agent remote container actions are included. This is not official Wings compatibility or full Pterodactyl parity."
  echo "Minecraft server ports start at TCP 25565; allow the needed ports in the provider firewall."
else
  echo "Service did not start. Check: journalctl -u t-panel -n 100 --no-pager"
  exit 1
fi
