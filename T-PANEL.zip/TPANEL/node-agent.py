#!/usr/bin/env python3
"""T PANEL Remote Node Agent. Run only on trusted networks behind HTTPS/reverse proxy."""
import http.server, json, os, subprocess, secrets, re
from urllib.parse import urlparse, unquote
TOKEN=os.environ.get('TPANEL_NODE_TOKEN','')
HOST=os.environ.get('TPANEL_NODE_BIND','127.0.0.1')
PORT=int(os.environ.get('TPANEL_NODE_PORT','8790'))
if len(TOKEN)<24: raise SystemExit('TPANEL_NODE_TOKEN must be at least 24 characters')
NAME=os.environ.get('TPANEL_NODE_NAME','T PANEL node')
class Handler(http.server.BaseHTTPRequestHandler):
 def log_message(self,*a): pass
 def send(self,code,obj):
  data=json.dumps(obj).encode(); self.send_response(code); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(data))); self.end_headers(); self.wfile.write(data)
 def authorized(self):
  supplied=self.headers.get('Authorization','')
  return secrets.compare_digest(supplied, 'Bearer '+TOKEN)
 def do_GET(self):
  path=urlparse(self.path).path
  if path=='/health':
   if not self.authorized(): return self.send(401,{'error':'unauthorized'})
   try:
    r=subprocess.run(['docker','info','--format','{{.ServerVersion}}'],capture_output=True,text=True,timeout=4)
    if r.returncode: return self.send(503,{'node':NAME,'docker':'unavailable'})
    return self.send(200,{'node':NAME,'status':'online','dockerVersion':r.stdout.strip()})
   except Exception: return self.send(503,{'node':NAME,'docker':'unavailable'})
  if not self.authorized(): return self.send(401,{'error':'unauthorized'})
  if path=='/containers':
   try:
    r=subprocess.run(['docker','ps','-a','--format','{{json .}}'],capture_output=True,text=True,timeout=8,check=True)
    rows=[json.loads(x) for x in r.stdout.splitlines() if x.strip()]
    return self.send(200,{'containers':rows})
   except Exception: return self.send(503,{'error':'docker query failed'})
  m=re.fullmatch(r'/containers/([A-Za-z0-9_.-]{1,100})/logs',path)
  if m:
   try:
    r=subprocess.run(['docker','logs','--tail','150',m.group(1)],capture_output=True,text=True,timeout=8)
    return self.send(200,{'logs':(r.stdout+'\n'+r.stderr)[-50000:]})
   except Exception:return self.send(503,{'error':'logs unavailable'})
  return self.send(404,{'error':'not found'})
 def do_POST(self):
  if not self.authorized(): return self.send(401,{'error':'unauthorized'})
  path=urlparse(self.path).path
  m=re.fullmatch(r'/containers/([A-Za-z0-9_.-]{1,100})/(start|stop|restart)',path)
  if not m:return self.send(404,{'error':'not found'})
  action=m.group(2); name=m.group(1)
  try:
   r=subprocess.run(['docker',action,name],capture_output=True,text=True,timeout=45)
   return self.send(200 if r.returncode==0 else 400,{'ok':r.returncode==0,'output':(r.stdout+'\n'+r.stderr)[-4000:]})
  except subprocess.TimeoutExpired:return self.send(504,{'error':'docker action timed out'})
if __name__=='__main__':
 print(f'T PANEL Node Agent listening on {HOST}:{PORT}; protect it with a firewall and HTTPS reverse proxy')
 http.server.ThreadingHTTPServer((HOST,PORT),Handler).serve_forever()
