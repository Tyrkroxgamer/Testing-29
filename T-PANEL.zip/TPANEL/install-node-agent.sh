#!/usr/bin/env bash
set -Eeuo pipefail
if [[ $EUID -ne 0 ]]; then echo 'Run as root: sudo bash install-node-agent.sh'; exit 1; fi
command -v apt-get >/dev/null || { echo 'Ubuntu/Debian only'; exit 1; }

# Install one consistent Docker package family. Do not silently remove a runtime
# that may own existing containers.
is_installed() {
  dpkg-query -W -f='${db:Status-Status}' "$1" 2>/dev/null | grep -qx 'installed'
}

repair_apt_state() {
  if apt-get check; then return 0; fi
  echo "APT reports broken or conflicting package dependencies."
  echo "A simulated repair is shown below; review package removals before approving."
  apt-get -s --fix-broken install || true
  read -rp "Attempt apt --fix-broken install now? [y/N]: " REPAIR_APT
  [[ "$REPAIR_APT" =~ ^[Yy]$ ]] || { echo "Package repair cancelled. No packages were removed by this script."; return 1; }
  apt-get --fix-broken install -y
  apt-get check
}

install_docker_stack() {
  if docker info >/dev/null 2>&1; then
    echo "Docker is already working; keeping the current installation."
    return 0
  fi

  if is_installed docker-ce; then
    if is_installed containerd; then
      echo "Docker CE is installed alongside the conflicting distro 'containerd' package."
      read -rp "Remove distro containerd and keep Docker CE/containerd.io? Existing containers may be affected [y/N]: " ANSWER
      [[ "$ANSWER" =~ ^[Yy]$ ]] || { echo "Cancelled without removing packages."; return 1; }
      systemctl stop docker containerd 2>/dev/null || true
      apt-get remove -y containerd
    fi
    apt-get --fix-broken install -y
    apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
  elif is_installed docker.io; then
    if is_installed containerd.io; then
      echo "Mixed Docker packages detected: docker.io conflicts with containerd.io."
      read -rp "Switch to Ubuntu/Debian docker.io and remove Docker CE/containerd.io packages? Existing containers may be affected [y/N]: " ANSWER
      [[ "$ANSWER" =~ ^[Yy]$ ]] || { echo "Cancelled without removing packages."; return 1; }
      systemctl stop docker containerd 2>/dev/null || true
      apt-get remove -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
      apt-get --fix-broken install -y
      apt-get install -y docker.io
    fi
  elif is_installed containerd.io; then
    echo "containerd.io is installed but Docker CE is not; avoid mixing package families."
    read -rp "Remove containerd.io and use Ubuntu/Debian docker.io? Existing container workloads may be affected [y/N]: " ANSWER
    [[ "$ANSWER" =~ ^[Yy]$ ]] || { echo "Cancelled without removing packages."; return 1; }
    systemctl stop docker containerd 2>/dev/null || true
    apt-get remove -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
    apt-get --fix-broken install -y
    apt-get install -y docker.io
  else
    apt-get --fix-broken install -y
    apt-get install -y docker.io
  fi

  systemctl enable --now docker
  docker info >/dev/null 2>&1 || {
    echo "Docker packages installed, but the daemon is not healthy. Diagnostics:"
    systemctl --no-pager --full status docker || true
    journalctl -u docker -n 60 --no-pager || true
    return 1
  }
}

read -rp 'Panel VPS private/public IP allowed to connect: ' PANEL_IP
[[ "$PANEL_IP" =~ ^[0-9a-fA-F:.]+$ ]] || { echo 'Invalid IP'; exit 1; }
read -rsp 'Shared token (minimum 24 characters; same token entered in T PANEL Admin > Register Node): ' TOKEN; echo
(( ${#TOKEN} >= 24 )) || { echo 'Token must be at least 24 characters'; exit 1; }
apt-get update
repair_apt_state
apt-get install -y python3
install_docker_stack
install -d -m 750 /opt/t-panel-node
install -m 750 "$(dirname "$0")/node-agent.py" /opt/t-panel-node/node-agent.py
umask 077
cat > /etc/t-panel-node.env <<ENV
TPANEL_NODE_TOKEN=$TOKEN
TPANEL_NODE_NAME=$(hostname | tr -cd 'A-Za-z0-9_.-')
TPANEL_NODE_BIND=0.0.0.0
TPANEL_NODE_PORT=8790
ENV
chmod 600 /etc/t-panel-node.env
cat > /etc/systemd/system/t-panel-node-agent.service <<'UNIT'
[Unit]
Description=T PANEL Remote Node Agent
After=network.target docker.service
Requires=docker.service
[Service]
Type=simple
EnvironmentFile=/etc/t-panel-node.env
ExecStart=/usr/bin/python3 /opt/t-panel-node/node-agent.py
Restart=on-failure
RestartSec=3
NoNewPrivileges=true
PrivateTmp=true
ProtectHome=true
ProtectSystem=full
ReadWritePaths=/opt/t-panel-node
[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable --now t-panel-node-agent
if command -v ufw >/dev/null && ufw status | grep -q 'Status: active'; then ufw allow from "$PANEL_IP" to any port 8790 proto tcp; else echo 'WARNING: UFW is not active. Restrict TCP 8790 to the panel IP in your provider firewall before use.'; fi
unset TOKEN
echo 'Node agent installed.'
echo 'In T PANEL Admin > Register a Node, set endpoint to http://NODE_IP:8790 (prefer private VPN IP) and enter the same shared token.'
echo 'For public-network use, put this agent behind HTTPS and firewall it to the panel IP. Do not expose port 8790 to everyone.'
echo 'Logs: journalctl -u t-panel-node-agent -f'
