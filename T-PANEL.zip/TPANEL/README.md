# T PANEL Enhanced (MVP)

T PANEL is a Spring Boot panel for local Docker-based Paper Minecraft servers. It includes local server lifecycle actions, an RCON-backed command form with live log refresh, a server-data file manager, ZIP backups, interval-based scheduled backups, user/admin management, and an optional separate T PANEL Node Agent for viewing and starting/stopping/restarting Docker containers on a remote node.

## Install panel

On Ubuntu/Debian, extract the ZIP and run:

```bash
sudo bash install.sh
```

Use port `8088` or another free port, then enter an admin email and a strong password (12+ characters). Allow the panel port in the VPS provider firewall. Open `http://PANEL_IP:8088`; for public hosting, configure HTTPS before using it with real users.

## Remote node agent

On each separate Ubuntu/Debian Docker node, copy `node-agent.py` and `install-node-agent.sh` from this project, then run:

```bash
sudo bash install-node-agent.sh
```

Enter the panel VPS IP and a long random shared token. Enter the same token and endpoint such as `http://NODE_PRIVATE_IP:8790` under Admin Panel > Register a Node. Prefer a private VPN network. The installer adds a UFW rule for the panel IP if UFW is active. If UFW is inactive, configure your provider firewall manually; never expose port 8790 to the whole internet. The agent runs with access to Docker, so anyone who steals its token can control containers on that node.

This is a custom T PANEL agent, **not the official Pterodactyl Wings API**. Admin can test connection and manage existing remote Docker containers. The local server-creation form still provisions on the panel VPS; fully integrated remote allocation/provisioning, WebSocket console on remote nodes, TLS automation, encrypted node-token storage, audit logs, full permissions, restore workflow, and full Pterodactyl parity are not implemented.

## Included

- Admin/user accounts and roles
- Local Docker-based Paper server create/start/stop/restart/delete
- Live-refreshing log console and RCON command sending
- File listing, upload (up to 100 MB), download and single-file delete
- ZIP backup creation/download
- Automatic ZIP backup schedules (60 minutes to 7 days)
- Custom remote Node Agent: health check, container listing, start/stop/restart

## Important operational notes

- Build requires Java 21 and Maven; `install.sh` installs them and builds the JAR.
- Backups are stored under `/opt/t-panel/backups/<server-id>` and can fill the disk. Monitor disk space and copy important backups offsite.
- Backup scheduling is interval-based, not a full cron/snapshot system. It backs up the server data directory; it does not stop the server first.
- Tokens are currently stored in the panel database in plaintext. Restrict OS/database access and do not treat this MVP as production-ready for untrusted customers.
- The application has not been compiled/tested in this build environment because Maven is unavailable here. Build it on the target server with the installer and check `journalctl -u t-panel -n 100 --no-pager` if startup fails.

### Docker/containerd package conflict
The installers now install Java/Maven/Python separately, reuse an existing Docker CLI if present, and check for a separately installed `containerd` package before installing Ubuntu's `docker.io`. If found, the installer asks before removing it because existing container workloads may be affected. Do not mix Ubuntu `docker.io` packages with Docker CE's `containerd.io` package family on the same host.

## Installer hardening (V4)

- Checks the APT dependency state before installing packages. If APT is broken, it shows a simulated `apt --fix-broken` plan and asks before attempting repair.
- Detects the installed Docker package family (`docker.io` versus Docker CE / `containerd.io`) and avoids silently switching families.
- If a package-family switch may stop existing containers, it asks for confirmation first.
- Verifies Docker daemon health after installation and prints `systemctl`/`journalctl` diagnostics when it cannot start.

This does not guarantee that every VPS-specific error is fixed: third-party APT repositories, held packages, provider firewalls, unsupported OS releases, insufficient disk/RAM, and application build errors can still require the exact output from that server. Maven build and full end-to-end runtime tests must be performed on a compatible Ubuntu/Debian VPS.
