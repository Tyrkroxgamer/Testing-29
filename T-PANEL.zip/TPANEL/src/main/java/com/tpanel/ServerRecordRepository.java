package com.tpanel;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ServerRecordRepository extends JpaRepository<ServerRecord, Long> {}
