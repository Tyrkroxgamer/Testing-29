package com.tpanel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class TPanelApplication {
    public static void main(String[] args) {
        SpringApplication.run(TPanelApplication.class, args);
    }
}
