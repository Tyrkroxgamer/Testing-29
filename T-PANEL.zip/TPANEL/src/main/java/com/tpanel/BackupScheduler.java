package com.tpanel;
import java.nio.file.*;import java.time.*;import java.time.format.DateTimeFormatter;import java.util.zip.*;import java.io.*;
import org.springframework.scheduling.annotation.Scheduled;import org.springframework.stereotype.Component;
@Component public class BackupScheduler {
 private final BackupScheduleRepository schedules; private final ServerRecordRepository servers;
 public BackupScheduler(BackupScheduleRepository schedules,ServerRecordRepository servers){this.schedules=schedules;this.servers=servers;}
 @Scheduled(fixedDelay=60000) public void runDue(){Instant now=Instant.now(); for(BackupSchedule s:schedules.findByEnabledTrueAndNextRunAtLessThanEqual(now)){try{if(servers.existsById(s.getServerId())) backup(s.getServerId());}catch(Exception ignored){} s.setNextRunAt(now.plusSeconds(s.getIntervalMinutes()*60L));schedules.save(s);}}
 private void backup(Long id)throws IOException{Path root=Path.of("/opt/t-panel/servers",String.valueOf(id));Files.createDirectories(root);Path dir=Path.of("/opt/t-panel/backups",String.valueOf(id));Files.createDirectories(dir);Path out=dir.resolve("scheduled-"+DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss").withZone(ZoneOffset.UTC).format(Instant.now())+".zip");try(ZipOutputStream z=new ZipOutputStream(Files.newOutputStream(out));var walk=Files.walk(root)){for(Path f:(Iterable<Path>)walk.filter(Files::isRegularFile)::iterator){z.putNextEntry(new ZipEntry(root.relativize(f).toString().replace('\\','/')));Files.copy(f,z);z.closeEntry();}}}
}
