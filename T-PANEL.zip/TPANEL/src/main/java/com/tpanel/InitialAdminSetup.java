package com.tpanel;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
public class InitialAdminSetup implements ApplicationRunner {
    private final UserAccountRepository users;
    private final PasswordEncoder encoder;
    @Value("${TPANEL_ADMIN_EMAIL:}") private String adminEmail;
    @Value("${TPANEL_ADMIN_PASSWORD:}") private String adminPassword;

    public InitialAdminSetup(UserAccountRepository users, PasswordEncoder encoder) {
        this.users = users; this.encoder = encoder;
    }

    @Override public void run(ApplicationArguments args) {
        if (users.existsByRole("ADMIN")) return;
        if (adminEmail == null || adminEmail.isBlank() || adminPassword == null || adminPassword.length() < 12) {
            System.err.println("T PANEL: no admin created. Set TPANEL_ADMIN_EMAIL and TPANEL_ADMIN_PASSWORD (12+ characters) before first start.");
            return;
        }
        users.save(new UserAccount(adminEmail.trim().toLowerCase(), encoder.encode(adminPassword), "ADMIN"));
        System.out.println("T PANEL: initial administrator created for " + adminEmail.trim().toLowerCase());
    }
}
