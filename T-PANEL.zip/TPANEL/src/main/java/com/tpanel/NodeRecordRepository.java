package com.tpanel;

import org.springframework.data.jpa.repository.JpaRepository;

public interface NodeRecordRepository extends JpaRepository<NodeRecord, Long> {
    boolean existsByNameIgnoreCase(String name);
}
