package com.tpanel;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "node_records")
public class NodeRecord {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 80)
    private String name;

    @Column(nullable = false, length = 255)
    private String endpoint;

    @Column(nullable = false, length = 100)
    private String location;

    @Column(length = 255)
    private String apiToken;

    @Column(nullable = false)
    private int totalMemoryMb;

    @Column(nullable = false)
    private int totalDiskGb;

    @Column(nullable = false)
    private boolean enabled = true;

    @Column(nullable = false)
    private Instant createdAt = Instant.now();

    protected NodeRecord() {}

    public NodeRecord(String name, String endpoint, String location, int totalMemoryMb, int totalDiskGb) { this(name, endpoint, location, totalMemoryMb, totalDiskGb, null); }

    public NodeRecord(String name, String endpoint, String location, int totalMemoryMb, int totalDiskGb, String apiToken) {
        this.name = name;
        this.endpoint = endpoint;
        this.location = location;
        this.apiToken = apiToken;
        this.totalMemoryMb = totalMemoryMb;
        this.totalDiskGb = totalDiskGb;
        this.enabled = true;
    }

    public Long getId() { return id; }
    public String getName() { return name; }
    public String getEndpoint() { return endpoint; }
    public String getLocation() { return location; }
    public String getApiToken() { return apiToken; }
    public int getTotalMemoryMb() { return totalMemoryMb; }
    public int getTotalDiskGb() { return totalDiskGb; }
    public boolean isEnabled() { return enabled; }
    public Instant getCreatedAt() { return createdAt; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }
}
