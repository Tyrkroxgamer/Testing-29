package com.tpanel;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "server_records")
public class ServerRecord {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false) private String name;
    @Column(nullable = false) private String minecraftVersion;
    @Column(nullable = false) private int memoryMb;
    @Column(nullable = false) private String status = "PENDING";
    @Column private String containerName;
    @Column private Integer hostPort;
    @Column(length = 1000) private String lastError;
    @Column(length = 80) private String rconPassword;
    @Column(nullable = false) private Instant createdAt = Instant.now();

    protected ServerRecord() {}
    public ServerRecord(String name, String minecraftVersion, int memoryMb) {
        this.name = name; this.minecraftVersion = minecraftVersion; this.memoryMb = memoryMb;
        this.status = "PENDING";
    }
    public Long getId() { return id; }
    public String getName() { return name; }
    public String getMinecraftVersion() { return minecraftVersion; }
    public int getMemoryMb() { return memoryMb; }
    public String getStatus() { return status; }
    public Instant getCreatedAt() { return createdAt; }
    public String getContainerName() { return containerName; }
    public Integer getHostPort() { return hostPort; }
    public String getLastError() { return lastError; }
    public String getRconPassword() { return rconPassword; }
    public void setStatus(String status) { this.status = status; }
    public void setContainerName(String containerName) { this.containerName = containerName; }
    public void setHostPort(Integer hostPort) { this.hostPort = hostPort; }
    public void setLastError(String lastError) { this.lastError = lastError; }
    public void setRconPassword(String value) { this.rconPassword = value; }
}
