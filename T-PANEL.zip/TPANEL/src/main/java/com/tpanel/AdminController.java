package com.tpanel;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import java.security.Principal;
import java.util.Locale;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/admin")
public class AdminController {
    private final UserAccountRepository users;
    private final NodeRecordRepository nodes;
    private final ServerRecordRepository servers;
    private final PasswordEncoder encoder;

    public AdminController(UserAccountRepository users, NodeRecordRepository nodes,
                           ServerRecordRepository servers, PasswordEncoder encoder) {
        this.users = users;
        this.nodes = nodes;
        this.servers = servers;
        this.encoder = encoder;
    }

    @GetMapping
    public String admin(Model model) {
        model.addAttribute("users", users.findAll());
        model.addAttribute("nodes", nodes.findAll());
        model.addAttribute("serverCount", servers.count());
        model.addAttribute("adminCount", users.findAll().stream().filter(u -> "ADMIN".equals(u.getRole())).count());
        model.addAttribute("userForm", new UserForm());
        model.addAttribute("nodeForm", new NodeForm());
        return "admin";
    }

    @PostMapping("/users")
    public String createUser(@Valid @ModelAttribute("userForm") UserForm form,
                             BindingResult result, Model model, RedirectAttributes flash) {
        String email = form.getEmail() == null ? "" : form.getEmail().trim().toLowerCase(Locale.ROOT);
        if (!result.hasErrors() && users.findByEmailIgnoreCase(email).isPresent()) {
            result.rejectValue("email", "duplicate", "An account with this email already exists.");
        }
        if (result.hasErrors()) {
            loadAdmin(model);
            return "admin";
        }
        String role = "ADMIN".equals(form.getRole()) ? "ADMIN" : "USER";
        users.save(new UserAccount(email, encoder.encode(form.getPassword()), role));
        flash.addFlashAttribute("notice", "User account created.");
        return "redirect:/admin";
    }

    @PostMapping("/users/{id}/role")
    public String changeRole(@PathVariable Long id, @RequestParam String role,
                             Principal principal, RedirectAttributes flash) {
        UserAccount target = users.findById(id).orElse(null);
        if (target == null) {
            flash.addFlashAttribute("error", "User not found.");
            return "redirect:/admin";
        }
        String newRole = "ADMIN".equals(role) ? "ADMIN" : "USER";
        if ("ADMIN".equals(target.getRole()) && !"ADMIN".equals(newRole)
                && users.findAll().stream().filter(u -> "ADMIN".equals(u.getRole())).count() <= 1) {
            flash.addFlashAttribute("error", "Cannot demote the last administrator.");
            return "redirect:/admin";
        }
        // Updating the role by replacing the record avoids exposing password hashes in the UI.
        users.save(new UserAccountRoleUpdater(users).update(target, newRole));
        flash.addFlashAttribute("notice", "User role updated.");
        return "redirect:/admin";
    }

    @PostMapping("/users/{id}/delete")
    public String deleteUser(@PathVariable Long id, Principal principal, RedirectAttributes flash) {
        UserAccount target = users.findById(id).orElse(null);
        if (target == null) {
            flash.addFlashAttribute("error", "User not found.");
            return "redirect:/admin";
        }
        if (target.getEmail().equalsIgnoreCase(principal.getName())) {
            flash.addFlashAttribute("error", "You cannot delete the account you are currently using.");
            return "redirect:/admin";
        }
        if ("ADMIN".equals(target.getRole())
                && users.findAll().stream().filter(u -> "ADMIN".equals(u.getRole())).count() <= 1) {
            flash.addFlashAttribute("error", "Cannot delete the last administrator.");
            return "redirect:/admin";
        }
        users.delete(target);
        flash.addFlashAttribute("notice", "User deleted.");
        return "redirect:/admin";
    }

    @PostMapping("/nodes")
    public String addNode(@Valid @ModelAttribute("nodeForm") NodeForm form,
                          BindingResult result, Model model, RedirectAttributes flash) {
        String name = form.getName() == null ? "" : form.getName().trim();
        if (!result.hasErrors() && nodes.existsByNameIgnoreCase(name)) {
            result.rejectValue("name", "duplicate", "A node with this name already exists.");
        }
        if (result.hasErrors()) {
            loadAdmin(model);
            return "admin";
        }
        String endpoint = form.getEndpoint().trim();
        if (!(endpoint.startsWith("http://") || endpoint.startsWith("https://"))) {
            result.rejectValue("endpoint", "scheme", "Endpoint must start with http:// or https://.");
            loadAdmin(model);
            return "admin";
        }
        nodes.save(new NodeRecord(name, endpoint, form.getLocation().trim(),
                form.getTotalMemoryMb(), form.getTotalDiskGb(), form.getApiToken().trim()));
        flash.addFlashAttribute("notice", "Remote node registered. Use Test Connection to verify its T PANEL Node Agent.");
        return "redirect:/admin";
    }

    @PostMapping("/nodes/{id}/test")
    public String testNode(@PathVariable Long id, RedirectAttributes flash) {
        NodeRecord node=nodes.findById(id).orElse(null);
        if(node==null){flash.addFlashAttribute("error","Node not found.");return "redirect:/admin";}
        try {
            java.net.http.HttpRequest request=java.net.http.HttpRequest.newBuilder(java.net.URI.create(node.getEndpoint().replaceAll("/$", "")+"/health"))
                .timeout(java.time.Duration.ofSeconds(6)).header("Authorization","Bearer "+node.getApiToken()).GET().build();
            java.net.http.HttpResponse<String> response=java.net.http.HttpClient.newBuilder().connectTimeout(java.time.Duration.ofSeconds(4)).build().send(request,java.net.http.HttpResponse.BodyHandlers.ofString());
            if(response.statusCode()==200){flash.addFlashAttribute("notice","Remote node "+node.getName()+" connected: "+response.body());}
            else flash.addFlashAttribute("error","Node connection failed. HTTP "+response.statusCode()+". Check endpoint, token, firewall and agent service.");
        } catch(Exception e){flash.addFlashAttribute("error","Node connection failed: "+e.getClass().getSimpleName()+". Check URL, token, firewall and agent service.");}
        return "redirect:/admin";
    }

    @GetMapping("/nodes/{id}/containers")
    public String remoteContainers(@PathVariable Long id, Model model, RedirectAttributes flash) {
        NodeRecord node=nodes.findById(id).orElse(null); if(node==null){flash.addFlashAttribute("error","Node not found.");return "redirect:/admin";}
        try { var req=java.net.http.HttpRequest.newBuilder(java.net.URI.create(node.getEndpoint().replaceAll("/$","")+"/containers")).timeout(java.time.Duration.ofSeconds(8)).header("Authorization","Bearer "+node.getApiToken()).GET().build(); var res=java.net.http.HttpClient.newHttpClient().send(req,java.net.http.HttpResponse.BodyHandlers.ofString()); if(res.statusCode()!=200) throw new IllegalStateException("Agent returned HTTP "+res.statusCode());
            var parsed=new com.fasterxml.jackson.databind.ObjectMapper().readTree(res.body()); java.util.List<java.util.Map<String,Object>> rows=new com.fasterxml.jackson.databind.ObjectMapper().convertValue(parsed.path("containers"), new com.fasterxml.jackson.core.type.TypeReference<java.util.List<java.util.Map<String,Object>>>(){}); model.addAttribute("containers",rows); model.addAttribute("node",node); return "remote-containers";
        } catch(Exception e){flash.addFlashAttribute("error","Cannot fetch remote containers. Check agent/network. "+e.getClass().getSimpleName());return "redirect:/admin";}
    }
    @PostMapping("/nodes/{id}/containers/{container}/{action}")
    public String remoteContainerAction(@PathVariable Long id,@PathVariable String container,@PathVariable String action,RedirectAttributes flash){
        NodeRecord node=nodes.findById(id).orElse(null); if(node==null)return "redirect:/admin";
        if(!container.matches("[A-Za-z0-9_.-]{1,100}")||!java.util.Set.of("start","stop","restart").contains(action)){flash.addFlashAttribute("error","Invalid container action.");return "redirect:/admin/nodes/"+id+"/containers";}
        try{var req=java.net.http.HttpRequest.newBuilder(java.net.URI.create(node.getEndpoint().replaceAll("/$","")+"/containers/"+container+"/"+action)).timeout(java.time.Duration.ofSeconds(50)).header("Authorization","Bearer "+node.getApiToken()).POST(java.net.http.HttpRequest.BodyPublishers.noBody()).build();var res=java.net.http.HttpClient.newHttpClient().send(req,java.net.http.HttpResponse.BodyHandlers.ofString());if(res.statusCode()!=200)throw new IllegalStateException("Agent returned HTTP "+res.statusCode());flash.addFlashAttribute("notice","Remote container "+action+" requested.");}catch(Exception e){flash.addFlashAttribute("error","Remote action failed: "+e.getClass().getSimpleName());}return "redirect:/admin/nodes/"+id+"/containers";
    }

    @PostMapping("/nodes/{id}/toggle")
    public String toggleNode(@PathVariable Long id, RedirectAttributes flash) {
        NodeRecord node = nodes.findById(id).orElse(null);
        if (node == null) {
            flash.addFlashAttribute("error", "Node not found.");
        } else {
            node.setEnabled(!node.isEnabled());
            nodes.save(node);
            flash.addFlashAttribute("notice", "Node status updated.");
        }
        return "redirect:/admin";
    }

    @PostMapping("/nodes/{id}/delete")
    public String deleteNode(@PathVariable Long id, RedirectAttributes flash) {
        if (nodes.existsById(id)) {
            nodes.deleteById(id);
            flash.addFlashAttribute("notice", "Node removed from the registry.");
        } else {
            flash.addFlashAttribute("error", "Node not found.");
        }
        return "redirect:/admin";
    }

    private void loadAdmin(Model model) {
        model.addAttribute("users", users.findAll());
        model.addAttribute("nodes", nodes.findAll());
        model.addAttribute("serverCount", servers.count());
        model.addAttribute("adminCount", users.findAll().stream().filter(u -> "ADMIN".equals(u.getRole())).count());
        if (!model.containsAttribute("userForm")) model.addAttribute("userForm", new UserForm());
        if (!model.containsAttribute("nodeForm")) model.addAttribute("nodeForm", new NodeForm());
    }

    public static class UserForm {
        @NotBlank @Email private String email;
        @NotBlank @Size(min = 12, max = 200) private String password;
        private String role = "USER";
        public String getEmail() { return email; }
        public void setEmail(String email) { this.email = email; }
        public String getPassword() { return password; }
        public void setPassword(String password) { this.password = password; }
        public String getRole() { return role; }
        public void setRole(String role) { this.role = role; }
    }

    public static class NodeForm {
        @NotBlank @Size(max = 80) private String name;
        @NotBlank @Size(max = 255) private String endpoint;
        @NotBlank @Size(max = 100) private String location = "Unspecified";
        @Min(512) private int totalMemoryMb = 4096;
        @Min(1) private int totalDiskGb = 50;
        @NotBlank @Size(min=24,max=255) private String apiToken;
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public String getEndpoint() { return endpoint; }
        public void setEndpoint(String endpoint) { this.endpoint = endpoint; }
        public String getLocation() { return location; }
        public void setLocation(String location) { this.location = location; }
        public int getTotalMemoryMb() { return totalMemoryMb; }
        public void setTotalMemoryMb(int totalMemoryMb) { this.totalMemoryMb = totalMemoryMb; }
        public int getTotalDiskGb() { return totalDiskGb; }
        public void setTotalDiskGb(int totalDiskGb) { this.totalDiskGb = totalDiskGb; }
        public String getApiToken(){return apiToken;} public void setApiToken(String v){this.apiToken=v;}
    }

    /*
     * Keep role updates limited to the role field; this helper preserves the existing
     * password hash and email without adding a public password-hash setter.
     */
    private static class UserAccountRoleUpdater {
        private final UserAccountRepository repository;
        UserAccountRoleUpdater(UserAccountRepository repository) { this.repository = repository; }
        UserAccount update(UserAccount target, String role) {
            target.setRole(role);
            return repository.save(target);
        }
    }
}
