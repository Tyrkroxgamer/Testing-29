package com.tpanel;
import jakarta.persistence.*;
import java.time.Instant;
@Entity @Table(name="backup_schedules")
public class BackupSchedule {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long id;
 @Column(nullable=false) private Long serverId;
 @Column(nullable=false) private int intervalMinutes;
 @Column(nullable=false) private Instant nextRunAt=Instant.now();
 @Column(nullable=false) private boolean enabled=true;
 protected BackupSchedule(){}
 public BackupSchedule(Long serverId,int intervalMinutes){this.serverId=serverId;this.intervalMinutes=intervalMinutes;this.nextRunAt=Instant.now().plusSeconds(intervalMinutes*60L);}
 public Long getId(){return id;} public Long getServerId(){return serverId;} public int getIntervalMinutes(){return intervalMinutes;} public Instant getNextRunAt(){return nextRunAt;} public boolean isEnabled(){return enabled;} public void setEnabled(boolean v){enabled=v;} public void setNextRunAt(Instant v){nextRunAt=v;}
}
