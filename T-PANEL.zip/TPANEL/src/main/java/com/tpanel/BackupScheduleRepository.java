package com.tpanel;
import java.time.Instant;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
public interface BackupScheduleRepository extends JpaRepository<BackupSchedule,Long>{ List<BackupSchedule> findByEnabledTrueAndNextRunAtLessThanEqual(Instant time); List<BackupSchedule> findByServerId(Long id); }
