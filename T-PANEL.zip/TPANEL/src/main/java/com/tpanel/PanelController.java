package com.tpanel;

import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import java.io.IOException;
import java.nio.file.*;
import java.time.Instant;
import java.util.UUID;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class PanelController {
    private final ServerRecordRepository servers;
    private final BackupScheduleRepository schedules;
    private static final Pattern VERSION = Pattern.compile("[A-Za-z0-9._-]{1,32}");
    public PanelController(ServerRecordRepository servers, BackupScheduleRepository schedules) { this.servers = servers; this.schedules=schedules; }

    @GetMapping("/login") public String login() { return "login"; }
    @GetMapping("/setup-status") @ResponseBody public String setupStatus() { return "T PANEL is running."; }

    @GetMapping("/") public String dashboard(Model model) {
        model.addAttribute("servers", servers.findAll());
        model.addAttribute("serverForm", new ServerForm());
        model.addAttribute("dockerAvailable", dockerAvailable());
        return "dashboard";
    }

    @PostMapping("/servers")
    public String createServer(@Valid @ModelAttribute("serverForm") ServerForm form, BindingResult result, Model model, RedirectAttributes flash) {
        if (!VERSION.matcher(form.getMinecraftVersion() == null ? "" : form.getMinecraftVersion()).matches()) {
            result.rejectValue("minecraftVersion", "invalid", "Use a version like 1.21.10");
        }
        if (result.hasErrors()) {
            model.addAttribute("servers", servers.findAll()); model.addAttribute("dockerAvailable", dockerAvailable());
            return "dashboard";
        }
        ServerRecord record = servers.save(new ServerRecord(form.getName().trim(), form.getMinecraftVersion().trim(), form.getMemoryMb()));
        int port = 25565 + Math.toIntExact(record.getId() - 1);
        String container = "tpanel-mc-" + record.getId();
        record.setContainerName(container); record.setHostPort(port); record.setRconPassword(UUID.randomUUID().toString().replace("-", ""));
        try {
            if (!dockerAvailable()) throw new IllegalStateException("Docker is not installed or not running. Install Docker and restart T PANEL.");
            java.nio.file.Files.createDirectories(java.nio.file.Path.of("/opt/t-panel/servers", String.valueOf(record.getId())));
            runDocker("run", "-d", "--name", container, "--restart", "unless-stopped", "--memory", record.getMemoryMb() + "m",
                "-e", "EULA=TRUE", "-e", "TYPE=PAPER", "-e", "VERSION=" + record.getMinecraftVersion(), "-e", "MEMORY=" + Math.max(512, record.getMemoryMb() - 512) + "M", "-e", "ENABLE_RCON=true", "-e", "RCON_PASSWORD=" + record.getRconPassword(),
                "-p", port + ":25565", "-v", "/opt/t-panel/servers/" + record.getId() + ":/data", "itzg/minecraft-server:java21");
            record.setStatus("STARTING"); record.setLastError(null);
            flash.addFlashAttribute("notice", "Server container created. First boot may take several minutes; connect on port " + port + ".");
        } catch (Exception e) {
            record.setStatus("FAILED"); record.setLastError(safeError(e.getMessage()));
            flash.addFlashAttribute("notice", "Server record saved, but provisioning failed: " + record.getLastError());
        }
        servers.save(record);
        return "redirect:/";
    }

    @PostMapping("/servers/{id}/{action}")
    public String serverAction(@PathVariable Long id, @PathVariable String action, RedirectAttributes flash) {
        ServerRecord s = servers.findById(id).orElse(null);
        if (s == null || s.getContainerName() == null) { flash.addFlashAttribute("notice", "Server/container not found."); return "redirect:/"; }
        try {
            switch (action) {
                case "start" -> runDocker("start", s.getContainerName());
                case "stop" -> runDocker("stop", "-t", "30", s.getContainerName());
                case "restart" -> runDocker("restart", "-t", "30", s.getContainerName());
                case "refresh" -> { }
                case "delete" -> { try { runDocker("rm", "-f", s.getContainerName()); } catch (Exception ignored) {} servers.delete(s); flash.addFlashAttribute("notice", "Server record/container deleted. Data folder remains for safety."); return "redirect:/"; }
                default -> throw new IllegalArgumentException("Unsupported action");
            }
            String status = containerStatus(s.getContainerName());
            s.setStatus(status.toUpperCase(Locale.ROOT)); s.setLastError(null); servers.save(s);
            flash.addFlashAttribute("notice", "Server " + action + " request completed. Status: " + status + ".");
        } catch (Exception e) { s.setLastError(safeError(e.getMessage())); s.setStatus("ERROR"); servers.save(s); flash.addFlashAttribute("notice", "Action failed: " + s.getLastError()); }
        return "redirect:/";
    }

    @GetMapping("/servers/{id}/logs")
    public String serverLogs(@PathVariable Long id, Model model, RedirectAttributes flash) {
        ServerRecord s = servers.findById(id).orElse(null);
        if (s == null || s.getContainerName() == null) { flash.addFlashAttribute("notice", "Server not found."); return "redirect:/"; }
        model.addAttribute("server", s);
        try { model.addAttribute("logs", runDocker("logs", "--tail", "250", s.getContainerName())); }
        catch (Exception e) { model.addAttribute("logs", "Unable to fetch logs: " + safeError(e.getMessage())); }
        return "logs";
    }


    @GetMapping("/servers/{id}/console-data") @ResponseBody
    public ResponseEntity<String> consoleData(@PathVariable Long id) {
        ServerRecord s = servers.findById(id).orElse(null);
        if (s == null || s.getContainerName() == null) return ResponseEntity.notFound().build();
        try { return ResponseEntity.ok(runDocker("logs", "--tail", "250", s.getContainerName())); }
        catch (Exception e) { return ResponseEntity.status(503).body(safeError(e.getMessage())); }
    }

    @PostMapping("/servers/{id}/command") @ResponseBody
    public ResponseEntity<String> sendCommand(@PathVariable Long id, @RequestParam String command) {
        ServerRecord s = servers.findById(id).orElse(null);
        if (s == null || s.getContainerName() == null) return ResponseEntity.notFound().build();
        if (command == null || command.isBlank() || command.length() > 240 || command.matches(".*[\\r\\n].*")) return ResponseEntity.badRequest().body("Invalid command");
        try { return ResponseEntity.ok(runDocker("exec", s.getContainerName(), "rcon-cli", command)); }
        catch (Exception e) { return ResponseEntity.status(503).body("Command failed: " + safeError(e.getMessage())); }
    }

    @GetMapping("/servers/{id}/files")
    public String files(@PathVariable Long id, @RequestParam(defaultValue="") String path, Model model, RedirectAttributes flash) {
        ServerRecord s = servers.findById(id).orElse(null);
        if (s == null) { flash.addFlashAttribute("notice", "Server not found."); return "redirect:/"; }
        try {
            Path dir = safeServerPath(id, path);
            Files.createDirectories(dir);
            List<FileEntry> entries = new java.util.ArrayList<>();
            try (var stream = Files.list(dir)) { stream.sorted().forEach(f -> { try { entries.add(new FileEntry(f.getFileName().toString(), Files.isDirectory(f), Files.isDirectory(f) ? 0 : Files.size(f))); } catch (IOException ignored) {} }); }
            model.addAttribute("server", s); model.addAttribute("path", path); model.addAttribute("entries", entries); model.addAttribute("parentPath", parentPath(path));
        } catch (Exception e) { flash.addFlashAttribute("notice", "File listing failed: " + safeError(e.getMessage())); return "redirect:/"; }
        return "files";
    }

    @PostMapping("/servers/{id}/files/upload")
    public String uploadFile(@PathVariable Long id, @RequestParam(defaultValue="") String path, @RequestParam("file") MultipartFile file, RedirectAttributes flash) {
        try { if (file.isEmpty() || file.getSize() > 100L*1024*1024) throw new IOException("Select a file up to 100 MB."); Path target = safeServerPath(id, path).resolve(file.getOriginalFilename()).normalize(); if (!target.startsWith(serverRoot(id))) throw new IOException("Invalid path"); if (Files.exists(target) && !target.toRealPath().startsWith(serverRoot(id).toRealPath())) throw new IOException("Symlink path blocked"); Files.copy(file.getInputStream(), target, StandardCopyOption.REPLACE_EXISTING); flash.addFlashAttribute("notice", "File uploaded."); }
        catch (Exception e) { flash.addFlashAttribute("notice", "Upload failed: " + safeError(e.getMessage())); } return "redirect:/servers/"+id+"/files?path="+urlEncode(path);
    }

    @PostMapping("/servers/{id}/files/delete")
    public String deleteFile(@PathVariable Long id, @RequestParam String path, @RequestParam String name, RedirectAttributes flash) {
        try { Path parent=safeServerPath(id,path); Path target=parent.resolve(name).normalize(); if(!target.startsWith(serverRoot(id)) || target.equals(serverRoot(id))) throw new IOException("Invalid path"); if(Files.isDirectory(target)) throw new IOException("Delete files only; directories are not recursively deleted."); Files.deleteIfExists(target); flash.addFlashAttribute("notice","File deleted."); }
        catch(Exception e){flash.addFlashAttribute("notice","Delete failed: "+safeError(e.getMessage()));} return "redirect:/servers/"+id+"/files?path="+urlEncode(path);
    }

    @GetMapping("/servers/{id}/files/download")
    public ResponseEntity<byte[]> downloadFile(@PathVariable Long id, @RequestParam(defaultValue="") String path, @RequestParam String name) throws IOException {
        Path target=safeServerPath(id,path).resolve(name).normalize(); if(!target.startsWith(serverRoot(id)) || !Files.isRegularFile(target)) return ResponseEntity.notFound().build();
        byte[] data=Files.readAllBytes(target); return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION,"attachment; filename=\""+target.getFileName().toString().replace("\"", "")+"\"").contentType(MediaType.APPLICATION_OCTET_STREAM).body(data);
    }

    @PostMapping("/servers/{id}/backups")
    public String createBackup(@PathVariable Long id, RedirectAttributes flash) {
        try { ServerRecord s=servers.findById(id).orElseThrow(); Path root=serverRoot(id); Files.createDirectories(root); Path backupDir=Path.of("/opt/t-panel/backups",String.valueOf(id)); Files.createDirectories(backupDir); Path out=backupDir.resolve("backup-"+java.time.format.DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss").withZone(java.time.ZoneOffset.UTC).format(Instant.now())+".zip"); zipDirectory(root,out); flash.addFlashAttribute("notice","Backup created: "+out.getFileName()); }
        catch(Exception e){flash.addFlashAttribute("notice","Backup failed: "+safeError(e.getMessage()));} return "redirect:/servers/"+id+"/files";
    }

    @PostMapping("/servers/{id}/schedules")
    public String addSchedule(@PathVariable Long id,@RequestParam int intervalMinutes,RedirectAttributes flash){
        if(!servers.existsById(id)){flash.addFlashAttribute("notice","Server not found.");return "redirect:/";}
        if(intervalMinutes<60||intervalMinutes>10080){flash.addFlashAttribute("notice","Schedule interval must be between 60 minutes and 7 days.");return "redirect:/servers/"+id+"/backups";}
        schedules.save(new BackupSchedule(id,intervalMinutes));flash.addFlashAttribute("notice","Automatic backup schedule created.");return "redirect:/servers/"+id+"/backups";
    }
    @PostMapping("/servers/{id}/schedules/{scheduleId}/delete")
    public String deleteSchedule(@PathVariable Long id,@PathVariable Long scheduleId,RedirectAttributes flash){BackupSchedule s=schedules.findById(scheduleId).orElse(null);if(s!=null&&s.getServerId().equals(id)){schedules.delete(s);flash.addFlashAttribute("notice","Schedule removed.");}return "redirect:/servers/"+id+"/backups";}

    @GetMapping("/servers/{id}/backups")
    public String backups(@PathVariable Long id, Model model, RedirectAttributes flash) {
        if(!servers.existsById(id)){flash.addFlashAttribute("notice","Server not found.");return "redirect:/";}
        Path dir=Path.of("/opt/t-panel/backups",String.valueOf(id)); List<FileEntry> entries=new java.util.ArrayList<>();
        try { Files.createDirectories(dir); try(var stream=Files.list(dir)){stream.filter(Files::isRegularFile).sorted(java.util.Comparator.reverseOrder()).forEach(f->{try{entries.add(new FileEntry(f.getFileName().toString(),false,Files.size(f)));}catch(IOException ignored){}});} }catch(IOException ignored){}
        model.addAttribute("server",servers.findById(id).orElseThrow()); model.addAttribute("entries",entries); model.addAttribute("schedules",schedules.findByServerId(id)); return "backups";
    }

    @GetMapping("/servers/{id}/backups/download")
    public ResponseEntity<byte[]> downloadBackup(@PathVariable Long id,@RequestParam String name) throws IOException {
        if(name.contains("/")||name.contains("\\")||!name.endsWith(".zip")) return ResponseEntity.badRequest().build(); Path f=Path.of("/opt/t-panel/backups",String.valueOf(id),name).normalize(); if(!f.startsWith(Path.of("/opt/t-panel/backups",String.valueOf(id)))||!Files.isRegularFile(f)) return ResponseEntity.notFound().build();
        return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION,"attachment; filename=\""+name+"\"").contentType(MediaType.APPLICATION_OCTET_STREAM).body(Files.readAllBytes(f));
    }

    private Path serverRoot(Long id) { return Path.of("/opt/t-panel/servers",String.valueOf(id)).toAbsolutePath().normalize(); }
    private Path safeServerPath(Long id,String relative) throws IOException { Path root=serverRoot(id); Files.createDirectories(root); Path realRoot=root.toRealPath(); Path target=root.resolve(relative == null ? "" : relative).normalize(); if(!target.startsWith(root)) throw new IOException("Path traversal blocked"); if(Files.exists(target) && !target.toRealPath().startsWith(realRoot)) throw new IOException("Symlink path blocked"); return target; }
    private String parentPath(String path){ if(path==null||path.isBlank()) return ""; int i=path.lastIndexOf('/'); return i<0?"":path.substring(0,i); }
    private String urlEncode(String v){return java.net.URLEncoder.encode(v==null?"":v,java.nio.charset.StandardCharsets.UTF_8);}
    private void zipDirectory(Path root,Path out) throws IOException { try(ZipOutputStream zip=new ZipOutputStream(Files.newOutputStream(out)); var walk=Files.walk(root)){ for(Path f:(Iterable<Path>)walk.filter(Files::isRegularFile)::iterator){ if(f.equals(out))continue; zip.putNextEntry(new ZipEntry(root.relativize(f).toString().replace('\\','/'))); Files.copy(f,zip); zip.closeEntry(); } } }
    public record FileEntry(String name, boolean directory, long size) {}

    private boolean dockerAvailable() {
        try { Process p = new ProcessBuilder("docker", "info", "--format", "{{.ServerVersion}}").redirectErrorStream(true).start();
            boolean done = p.waitFor(3, java.util.concurrent.TimeUnit.SECONDS); if (!done) { p.destroyForcibly(); return false; } return p.exitValue() == 0;
        } catch (Exception e) { return false; }
    }
    private String containerStatus(String container) throws Exception { return runDocker("inspect", "--format", "{{.State.Status}}", container).trim(); }
    private String runDocker(String... args) throws Exception {
        java.util.ArrayList<String> cmd = new java.util.ArrayList<>(); cmd.add("docker"); cmd.addAll(List.of(args));
        Process p = new ProcessBuilder(cmd).redirectErrorStream(true).start();
        java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream();
        Thread reader = new Thread(() -> { try { p.getInputStream().transferTo(buffer); } catch (IOException ignored) {} });
        reader.setDaemon(true); reader.start();
        boolean done = p.waitFor(90, java.util.concurrent.TimeUnit.SECONDS);
        if (!done) { p.destroyForcibly(); throw new IOException("Docker command timed out"); }
        reader.join(2000);
        String output = buffer.toString(java.nio.charset.StandardCharsets.UTF_8);
        if (p.exitValue() != 0) throw new IOException(output.isBlank() ? "Docker command failed" : output.trim());
        return output;
    }
    private String safeError(String msg) { if (msg == null || msg.isBlank()) return "Unknown error"; return msg.length() > 900 ? msg.substring(0, 900) : msg; }

    public static class ServerForm {
        @NotBlank private String name;
        @NotBlank private String minecraftVersion = "1.21.10";
        @Min(1024) @Max(32768) private int memoryMb = 2048;
        public String getName() { return name; } public void setName(String name) { this.name = name; }
        public String getMinecraftVersion() { return minecraftVersion; } public void setMinecraftVersion(String v) { this.minecraftVersion = v; }
        public int getMemoryMb() { return memoryMb; } public void setMemoryMb(int m) { this.memoryMb = m; }
    }
}
